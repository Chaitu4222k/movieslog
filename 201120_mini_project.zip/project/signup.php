<?php require("signupclass.php") ?>
<?php
if (isset($_POST['submit'])) {
    $user = new RegisterUser($_POST['username'], $_POST['password']);
}
?>
<!doctype html>
<html>

<head>
    <script src="captcha.js"></script>
    <link href='https://fonts.googleapis.com/css?family=Nanum Brush Script' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Yellowtail' rel='stylesheet'>
    <link rel="stylesheet" href="test.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></
        script >
            <script
                src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"><
/script>
                <script
                    src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.m
in.js"></script>
</head>

<body>
    <h1>MOVIES LOG</h1>
    <marquee scrollamount="12">Cinema is interesting because we get to choose what to learn.Cinema is a reflection of society and,in most cases,has the ability to be a mirror and not just show problems but also give solutions and help them reach a large number of people through faces and voices that matter.</marquee>
    <div class="pages-right">
    </div>
    <br><br>
    <div class="p1">
        <p><strong>LOGIN PAGE</strong></p>
    </div>
    <br><br><br><br>
    <div class="input">
    
        <form style="text-align:center;" class="was-validated" action="" method="post" enctype="multipart/form-data"
            autocomplete="off">
            
            <h4>Click signin link if already have an account</h4><a href="login.php">Sign In</a>
            <div class="form-group">
                <label for="username">Username:</label><br>
                <input type="text" id="username" placeholder="Enter Username Here" name="username" required><br>
            </div>
            <div class="form-group">
                <label for="password">Password&#128274;:</label><br>
                <input type="password" id="password" placeholder="Enter Password Here" name="password" required><br>
            </div>
            <label>Enter Captcha:</label>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <input type="text" class="form-control" id="textinput" required>
                </div>
                <div class="form-group col-md-6">
                    <input type="text" class="form-control" readonly id="capt">
                </div>
                <h4>Regenerate Captcha <img src="https://w7.pngwing.com/pngs/365/764/png-transparent-computer-icons-
refresh-free-one-button-reload-text-logo-monochrome-thumbnail.png" width="15px" onload="cap()" onclick="cap()"></h4>
                
            </div>
            <button onclick="validcap()" type="submit" class="btn btn-outline-success
mr-2" name="submit">SignUp</button>
            <button type="reset" class="btn btn-outline-dark" value="Reset">Reset</button>
            <p class="error">
                <?php echo @$user->error ?>
            </p>
            <p class="success">
                <?php echo @$user->success ?>
            </p>
            </fieldset>

        </form>
    </div>
</body>

</html>