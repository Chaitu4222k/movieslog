<?php
session_start();
?>
<html>

<head>
  <link href='https://fonts.googleapis.com/css?family=Nanum Brush Script' rel='stylesheet'>
  <link href='https://fonts.googleapis.com/css?family=Yellowtail' rel='stylesheet'>
  <link rel="stylesheet" href="test.css">
</head>

<body>
  <h1>MOVIES LOG</h1>
  <marquee scrollamount="12">
    Cinema is interesting because we get to choose what to learn.Cinema is a reflection of society and,in most cases,has
    the ability to be a mirror and not just show problems but also give solutions and help them reach a large number of
    people through faces and voices that matter.
  </marquee>
  <br>
  <div class="pages-right">
    <a href="imdb.html">IMDb TOP 10</a>&emsp;
    <a href="lab1.php">Home</a>&emsp;
    <a href="trilogy.html">Top Rated Trilogies</a>&emsp;
  </div>
  <br>
  <div class="p1">
    <br>
    <b class="z">Welcome <?php echo htmlspecialchars($_SESSION['user']); ?></b>
    <p> <strong>Enter The Movie Name You Need To Log: </strong>
  </div>
  <div class="input">
    <form align="center" action="#" id="formSubmission" method="get">
      <label for="movie">Movie Name:</label>
      <input type="text" id="movie" name="movie"><br><br>
      <label for="date">Date and Time:</label>
      <input type="datetime-local" id="date" name="date">
      <input type="submit" value="Submit">
      <input type="reset">
    </form>
    </p>
    <br><br>
    <div class="table">
    <ul id="data">
      <li style="font-size:35px">movie</li>
      <li style="font-size:35px">date and time</li>
    </ul>
    </div>
  </div>
  <script>
    let form=document.getElementById("formSubmission");
    let table=document.getElementById('data');

    form.addEventListener("submit",(e)=>{
    e.preventDefault();
    submit();
    })

    const submit=()=>{
    let movie = document.getElementById("movie").value;
    let date = document.getElementById("date").value;

    let newArray = [movie, date];
      newArray.forEach((item) => {
        var li = document.createElement("li");
        var text = document.createTextNode(item);
        li.appendChild(text);
        table.appendChild(li);
      })
      form.reset();
    }
  </script>
</body>

</html>